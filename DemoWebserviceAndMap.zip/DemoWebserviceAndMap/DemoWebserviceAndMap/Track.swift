//
//  Track.swift
//  HalfTunes
//
//  Created by Ken Toh on 13/7/15.
//  Copyright (c) 2015 Ken Toh. All rights reserved.
//

class Track {
  var email: String?
  var image: String?
  var lat: String?
  var long: String?
  var username: String?
    
  
  init(email: String?, image: String?, lat: String?, long: String?, username: String?) {
    self.email = email
    self.image = image
    self.lat = lat
    self.long = long
    self.username = username
  }
}
