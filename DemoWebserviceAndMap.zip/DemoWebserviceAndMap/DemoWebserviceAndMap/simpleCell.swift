//
//  simpleCell.swift
//  DemoWebserviceAndMap
//
//  Created by piyush sinroja on 17/04/17.
//  Copyright © 2017 Piyush. All rights reserved.
//

import UIKit


 @objc protocol TrackCellDelegate : class {
    @objc optional func btnPauseTapped(_ cell: simpleCell)
    @objc optional func btnResumeTapped(_ cell: simpleCell)
    @objc optional func btnCancelTapped(_ cell: simpleCell)
    @objc optional func downloadTapped(_ cell: simpleCell)
}



class simpleCell: UITableViewCell {

    var delegate: TrackCellDelegate?
    
    @IBOutlet weak var viewDown: UIView!
    @IBOutlet weak var constrViewDownHeight: NSLayoutConstraint!
    @IBOutlet weak var progressView: UIProgressView!
    @IBOutlet weak var btnPauseResume: UIButton!
    @IBOutlet weak var btnCancel: UIButton!
    @IBOutlet weak var btnDownload: UIButton!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBAction func btnPauseResume(_ sender: Any) {
        if(btnPauseResume.titleLabel!.text == "Pause") {
            delegate?.btnPauseTapped!(self)
        } else {
            delegate?.btnResumeTapped!(self)
        }
    }
    
    @IBAction func btnCancel(_ sender: Any) {
        delegate?.btnCancelTapped!(self)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    @IBAction func downloadTapped(_ sender: AnyObject) {
        delegate?.downloadTapped!(self)
    }
}
